check_year=int(input(""))

#check leap year

if(check_year % 4 == 0 and check_year % 100 != 0) or (check_year % 400 == 0):

  print(check_year , '- leap year')

else:

  print(check_year , '- not a leap year')